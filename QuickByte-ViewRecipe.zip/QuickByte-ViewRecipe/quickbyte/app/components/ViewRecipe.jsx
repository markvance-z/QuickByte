'use client';
import { useEffect, useState } from 'react';

export default function ViewRecipe({ recipeId }) {
  const [recipe, setRecipe] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchRecipe() {
      const res = await fetch(`/api/recipes/${recipeId}`);
      const data = await res.json();
      setRecipe(data);
      setLoading(false);
    }

    if (recipeId) fetchRecipe();
  }, [recipeId]);

  if (loading) return <p>Loading...</p>;
  if (!recipe) return <p>Recipe not found.</p>;

  return (
    <div>
      <h2>{recipe.title}</h2>
      <p>{recipe.description}</p>
      <ul>
        {recipe.ingredients.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
      <p><strong>Steps:</strong> {recipe.instructions}</p>
    </div>
  );
}
