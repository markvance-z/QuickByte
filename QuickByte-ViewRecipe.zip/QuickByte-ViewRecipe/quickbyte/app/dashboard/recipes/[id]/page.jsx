'use client';
import { useParams } from 'next/navigation';
import ViewRecipe from '@/app/components/ViewRecipe';

export default function RecipePage() {
  const params = useParams();
  const id = params?.id;

  return (
    <div>
      <h1>View Recipe</h1>
      <ViewRecipe recipeId={id} />
    </div>
  );
}
