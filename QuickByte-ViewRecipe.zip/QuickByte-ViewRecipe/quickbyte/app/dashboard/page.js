'use client';

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import supabase from '../../lib/supabaseClient';

export default function Dashboard() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [allRecipes, setAllRecipes] = useState([]);

  // mock database
  const mockRecipes = [
    { id: 1, title: "Chicken breast", ingredients: "chicken, salt, pepper, olive oil" },
    { id: 2, title: "Kale salad", ingredients: "kale, tomatoes, onion, salt, pepper, olive oil" },
    { id: 3, title: "Gnocchi", ingredients: "gnocchi, salt, pepper, olive oil" },
    { id: 4, title: "Greek yogurt", ingredients: "greek yogurt, blueberries, honey" },
    { id: 5, title: "Sushi roll", ingredients: "white rice, seaweed, ahi tuna" }
  ];

  useEffect(() => {
    setAllRecipes(mockRecipes);
  }, []);

  const handleSearch = (e) => {
    setQuery(e.target.value);
  };

  const filteredRecipes = allRecipes.filter(recipe =>
    recipe.title.toLowerCase().includes(query.toLowerCase())
  );

  const handleRecipeClick = (id) => {
    router.push(`/dashboard/recipes/${id}`);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Dashboard</h1>
      <input
        type="text"
        placeholder="Search recipes..."
        value={query}
        onChange={handleSearch}
        style={{ padding: '8px', width: '300px' }}
      />

      <ul style={{ marginTop: '20px' }}>
        {filteredRecipes.map(recipe => (
          <li
            key={recipe.id}
            onClick={() => handleRecipeClick(recipe.id)}
            style={{ cursor: 'pointer', padding: '6px 0' }}
          >
            {recipe.title}
          </li>
        ))}
      </ul>
    </div>
  );
}
